<?php
/**
 * Setup aleb Child Theme's textdomain.
 *
 * Declare textdomain for this child theme.
 * Translations can be filed in the /languages/ directory.
 */
add_action( 'after_setup_theme', 'aleb_child_theme_setup' );
function aleb_child_theme_setup() {
	load_child_theme_textdomain( 'aleb-child', get_stylesheet_directory() . '/languages' );
}

add_action( 'wp_enqueue_scripts', 'aleb_child_scripts');
function aleb_child_scripts() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri(). '/style.css' );
}
