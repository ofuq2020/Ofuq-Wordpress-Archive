<?php 

function fix_img(){

	ob_start(); ?>

		<script>
			(function($){
		    
				$(window).load(function(){ 

				    $("#customize-controls img").css("width","auto");
				    $("#accordion-section-themes").css("display","none");
				    
			    });

			        
			})(jQuery);
		</script>


	<?php
	echo ob_get_clean();
}